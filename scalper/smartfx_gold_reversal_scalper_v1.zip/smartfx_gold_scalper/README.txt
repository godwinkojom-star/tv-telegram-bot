SMARTFX EXPERIMENTAL GOLD REVERSAL SCALPER
==========================================

This package is the isolated first-stage strategy engine for the new Gold
(XAU/USD) 1-minute reversal scalper.

IMPORTANT
---------
- It does NOT modify SmartFX app.py.
- It does NOT make API calls.
- It does NOT contain Telegram, Supabase, Render, or MT5 live execution.
- Feed it the existing shared-cache OHLC DataFrames from SmartFX.
- Test with historical/paper data before connecting any live execution.

FILES
-----
scalper/__init__.py
scalper/config.py
scalper/indicators.py
scalper/strategy.py

DESIGN
------
1m = entry/reversal trigger.
5m = confirmation timeframe.

The engine looks for a confirmed directional break with displacement, then
checks volatility, EMA separation, RSI, directional pressure, entry extension,
and risk/reward. It returns one SIGNAL or NO_SIGNAL result for the latest bar.

REVERSAL BEHAVIOUR
------------------
The caller/trade manager can keep one position at a time. When the current
position is BUY and a confirmed SELL arrives, should_reverse(...) returns True;
the position can then be closed and the SELL opened. The same applies to SELL -> BUY.

EXAMPLE
-------
from scalper import ScalperConfig, evaluate

cfg = ScalperConfig()
result = evaluate(df_1m, df_5m, cfg)
print(result)

The DataFrames must contain:
open, high, low, close

NEXT STAGE
----------
The next isolated files should be the paper engine and backtester. Only after
those results are acceptable should this strategy be connected to app.py's
shared cache, dashboard markers, or an MT5 bridge.
