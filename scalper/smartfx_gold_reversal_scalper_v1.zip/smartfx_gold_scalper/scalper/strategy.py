"""Original SmartFX experimental Gold reversal/scalping strategy.

This module is deliberately isolated from SmartFX app.py and the live V2/V3/ALCR
strategies. It consumes DataFrames supplied by the caller, so it does not make
market-data/API requests.
"""

from __future__ import annotations

from typing import Any, Dict, Optional
import math
import pandas as pd

from .config import ScalperConfig
from .indicators import (
    directional_candle_count,
    prepare_indicators,
    recent_swing_high,
    recent_swing_low,
)


def _empty_result(reason: str, **extra: Any) -> Dict[str, Any]:
    result = {"status": "NO_SIGNAL", "reason": reason}
    result.update(extra)
    return result


def _atr_value(row: pd.Series) -> Optional[float]:
    value = row.get("atr")
    if value is None or pd.isna(value) or float(value) <= 0:
        return None
    return float(value)


def confirmation_direction(df5: pd.DataFrame, cfg: ScalperConfig) -> str:
    if len(df5) < cfg.confirmation_slow_ema:
        return "NEUTRAL"
    row = df5.iloc[-1]
    fast = row["ema_fast"]
    slow = row["ema_slow"]
    close = row["close"]
    if pd.isna(fast) or pd.isna(slow):
        return "NEUTRAL"
    if close > fast > slow:
        return "BUY"
    if close < fast < slow:
        return "SELL"
    return "NEUTRAL"


def volatility_gate(row: pd.Series, cfg: ScalperConfig) -> tuple[bool, str]:
    atr_value = _atr_value(row)
    price = float(row["close"])
    if atr_value is None or price <= 0:
        return False, "ATR_NOT_READY"
    ratio = atr_value / price
    if ratio < cfg.min_atr_ratio:
        return False, "VOLATILITY_TOO_LOW"
    if ratio > cfg.max_atr_ratio:
        return False, "VOLATILITY_TOO_HIGH"
    return True, "OK"


def detect_reversal(df1: pd.DataFrame, cfg: ScalperConfig) -> Optional[str]:
    row = df1.iloc[-1]
    atr_value = _atr_value(row)
    if atr_value is None:
        return None

    swing_high = recent_swing_high(df1, cfg.swing_lookback)
    swing_low = recent_swing_low(df1, cfg.swing_lookback)
    body = float(row["body"])
    ratio = float(row["body_ratio"]) if not pd.isna(row["body_ratio"]) else 0.0
    minimum_body = cfg.displacement_atr * atr_value
    if body < minimum_body or ratio < cfg.displacement_ratio:
        return None

    if swing_high is not None and row["close"] > swing_high + cfg.reversal_break_atr * atr_value:
        return "BUY"
    if swing_low is not None and row["close"] < swing_low - cfg.reversal_break_atr * atr_value:
        return "SELL"
    return None


def anti_chop_gate(row: pd.Series, cfg: ScalperConfig) -> bool:
    atr_value = _atr_value(row)
    if atr_value is None:
        return False
    return abs(float(row["ema_fast"]) - float(row["ema_slow"])) >= cfg.min_ema_separation_atr * atr_value


def entry_quality_gate(
    row: pd.Series,
    direction: str,
    swing_level: Optional[float],
    cfg: ScalperConfig,
) -> bool:
    atr_value = _atr_value(row)
    if atr_value is None:
        return False
    close = float(row["close"])
    fast = float(row["ema_fast"])
    if abs(close - fast) > cfg.max_ema_distance_atr * atr_value:
        return False
    if swing_level is not None and abs(close - swing_level) > cfg.max_entry_extension_atr * atr_value:
        return False
    return True


def calculate_trade_levels(
    row: pd.Series,
    direction: str,
    cfg: ScalperConfig,
    swing_high: Optional[float],
    swing_low: Optional[float],
) -> Optional[Dict[str, float]]:
    entry = float(row["close"])
    atr_value = _atr_value(row)
    if atr_value is None:
        return None

    if direction == "BUY":
        structural = swing_low if swing_low is not None else entry - atr_value
        stop = min(entry - cfg.min_stop_atr * atr_value, structural - 0.05 * atr_value)
        risk = entry - stop
        target = entry + cfg.target_atr_multiplier * atr_value
    else:
        structural = swing_high if swing_high is not None else entry + atr_value
        stop = max(entry + cfg.min_stop_atr * atr_value, structural + 0.05 * atr_value)
        risk = stop - entry
        target = entry - cfg.target_atr_multiplier * atr_value

    risk_atr = risk / atr_value
    if not math.isfinite(risk_atr) or risk_atr < cfg.min_stop_atr or risk_atr > cfg.max_stop_atr:
        return None

    reward = abs(target - entry)
    rr = reward / risk if risk > 0 else 0.0
    if rr < cfg.minimum_rr:
        return None

    return {
        "entry": entry,
        "stop_loss": float(stop),
        "take_profit": float(target),
        "risk_distance": float(risk),
        "reward_distance": float(reward),
        "rr": float(rr),
        "atr": float(atr_value),
    }


def evaluate(
    df1: pd.DataFrame,
    df5: pd.DataFrame,
    cfg: Optional[ScalperConfig] = None,
) -> Dict[str, Any]:
    cfg = cfg or ScalperConfig()
    if len(df1) < cfg.minimum_1m_bars:
        return _empty_result("INSUFFICIENT_1M_HISTORY", required=cfg.minimum_1m_bars, available=len(df1))
    if len(df5) < cfg.minimum_5m_bars:
        return _empty_result("INSUFFICIENT_5M_HISTORY", required=cfg.minimum_5m_bars, available=len(df5))

    one = prepare_indicators(df1, cfg.fast_ema, cfg.slow_ema, cfg.rsi_period, cfg.atr_period)
    five = prepare_indicators(df5, cfg.confirmation_fast_ema, cfg.confirmation_slow_ema, cfg.rsi_period, cfg.atr_period)
    row = one.iloc[-1]

    volatility_ok, volatility_reason = volatility_gate(row, cfg)
    if not volatility_ok:
        return _empty_result(volatility_reason)

    confirm = confirmation_direction(five, cfg)
    reversal = detect_reversal(one, cfg)
    if reversal is None:
        return _empty_result("NO_CONFIRMED_REVERSAL", confirmation=confirm)

    if cfg.require_5m_confirmation and cfg.confirmation_required and confirm != reversal:
        return _empty_result("5M_CONFIRMATION_MISMATCH", signal_direction=reversal, confirmation=confirm)

    if not anti_chop_gate(row, cfg):
        return _empty_result("EMA_SEPARATION_TOO_SMALL")

    rsi_value = float(row["rsi"]) if not pd.isna(row["rsi"]) else None
    if rsi_value is None:
        return _empty_result("RSI_NOT_READY")
    if reversal == "BUY" and rsi_value < cfg.rsi_buy_min:
        return _empty_result("RSI_TOO_WEAK_FOR_BUY", rsi=rsi_value)
    if reversal == "SELL" and rsi_value > cfg.rsi_sell_max:
        return _empty_result("RSI_TOO_STRONG_FOR_SELL", rsi=rsi_value)

    directional_count = directional_candle_count(one, reversal, cfg.directional_window)
    if directional_count < 1:
        return _empty_result("NO_DIRECTIONAL_PRESSURE", count=directional_count)

    swing_high = recent_swing_high(one, cfg.swing_lookback)
    swing_low = recent_swing_low(one, cfg.swing_lookback)
    swing_level = swing_high if reversal == "BUY" else swing_low
    if not entry_quality_gate(row, reversal, swing_level, cfg):
        return _empty_result("ENTRY_TOO_EXTENDED")

    levels = calculate_trade_levels(row, reversal, cfg, swing_high, swing_low)
    if levels is None:
        return _empty_result("RISK_REWARD_INVALID")

    timestamp = one.index[-1] if len(one.index) else None
    return {
        "status": "SIGNAL",
        "pair": cfg.pair,
        "direction": reversal,
        "timestamp": timestamp,
        "confirmation": confirm,
        "rsi": rsi_value,
        "directional_candles": directional_count,
        "swing_high": swing_high,
        "swing_low": swing_low,
        **levels,
    }


def should_reverse(current_position: Optional[str], new_signal: Optional[Dict[str, Any]]) -> bool:
    if not current_position or not new_signal or new_signal.get("status") != "SIGNAL":
        return False
    return str(current_position).upper() != str(new_signal.get("direction", "")).upper()
